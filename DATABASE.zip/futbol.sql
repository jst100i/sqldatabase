-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 27, 2022 at 02:05 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `futbol`
--

-- --------------------------------------------------------

--
-- Table structure for table `clubs`
--

CREATE TABLE `clubs` (
  `TeamID` int(11) NOT NULL,
  `ClubName` varchar(30) NOT NULL,
  `League` varchar(30) NOT NULL,
  `Nation` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clubs`
--

INSERT INTO `clubs` (`TeamID`, `ClubName`, `League`, `Nation`) VALUES
(201, 'Seville', 'Liga de Espana', 'Spain'),
(202, 'Real Madrileno', 'Liga de Espana', 'Spain'),
(203, 'SL Benfica', 'Liga de Portugal', 'Portugal'),
(204, 'OL Chelsea', 'English Premier Divison', 'England'),
(205, 'Milan City', 'Prima Divisione Italiana', 'Italy'),
(206, 'Ajax', 'Liga van Nederland', 'Nederland'),
(207, 'Catalunya', 'Liga de Espana', 'Spain'),
(208, 'Flamengo', 'Liga do Brasil', 'Brasil'),
(209, 'Feyenoord', 'Liga van Nederland', 'Nederland'),
(210, 'AS Scows', 'English Premier Division', 'England'),
(211, 'Trafford', 'English Premier Divsion', 'England'),
(212, 'Woolwich Arsenal', 'English Premier Division', 'England'),
(213, 'Gradanski Zagreb', 'Prva Liga', 'Croatia'),
(214, 'Venezia', 'Prima Divisione Italiana', 'Italy'),
(215, 'Santos', 'Liga do Brasil', 'Brasil'),
(216, 'Marseille', 'Premiere Division', 'France');

-- --------------------------------------------------------

--
-- Table structure for table `gamestats`
--

CREATE TABLE `gamestats` (
  `PlayerID` int(11) NOT NULL,
  `LastName` varchar(30) DEFAULT NULL,
  `AreaOfPlay` varchar(30) DEFAULT NULL,
  `TeamID` int(11) DEFAULT NULL,
  `ClubName` varchar(30) DEFAULT NULL,
  `TotGames` int(11) DEFAULT NULL,
  `TotGoals` int(11) DEFAULT NULL,
  `TotAssists` int(11) DEFAULT NULL,
  `TotGameWinners` int(11) DEFAULT NULL,
  `TotKeyPasses` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gamestats`
--

INSERT INTO `gamestats` (`PlayerID`, `LastName`, `AreaOfPlay`, `TeamID`, `ClubName`, `TotGames`, `TotGoals`, `TotAssists`, `TotGameWinners`, `TotKeyPasses`) VALUES
(100, 'Macias', 'Forward', 201, 'Seville', 150, 73, 45, 40, 12),
(101, 'Shevchonskyi', 'Forward', 202, 'Real Madrileno', 330, 337, 20, 150, 30),
(102, 'Snijders', 'Midfielder', 209, 'Feyenoord', 130, 80, 60, 7, 250),
(103, 'Webb', 'Midfielder', 203, 'SL Benfica', 44, 7, 20, 0, 98),
(104, 'Romarizinho', 'Forward', 208, 'Flamengo', 247, 117, 83, 89, 59),
(105, 'Silva da Cruz', 'Forward', 206, 'Ajax', 74, 12, 22, 21, 30),
(106, 'Novikov', 'Midfielder', 205, 'Milan City', 134, 128, 112, 44, 270),
(107, 'Canez', 'Forward', 207, 'Catalunya', 163, 124, 66, 73, 40),
(108, 'Black', 'Midfielder', 204, 'OL Chelsea', 200, 79, 170, 33, 320),
(109, 'Frese', 'Forward', 202, 'Real Madrileno', 260, 270, 105, 120, 134),
(110, 'Germain', 'Forward', 201, 'Seville', 110, 41, 39, 27, 65),
(111, 'Luz', 'Midfield', 203, 'SL Benfica', 162, 72, 82, 79, 164),
(112, 'Ramos', 'Forward', 202, 'Real Madrileno', 30, 16, 12, 40, 63),
(111, 'Luz', 'Midfield', 203, 'SL Benfica', 162, 72, 82, 79, 164),
(112, 'Ramos', 'Forward', 202, 'Real Madrileno', 30, 16, 12, 40, 63),
(113, 'Botero', 'Midfield', 202, 'Real Madrileno', 100, 44, 92, 20, 184),
(114, 'Ricci', 'Midfield', 202, 'Real Madrileno', 140, 65, 42, 93, 87),
(115, 'Deschamps', 'Forward', 202, 'Real Madrileno', 234, 203, 103, 162, 193),
(116, 'Bielsa', 'Midfield', 202, 'Real Madrileno', 74, 3, 49, 0, 65),
(117, 'Soares', 'Forward', 202, 'Real Madrileno', 84, 52, 22, 12, 10),
(118, 'Ferron', 'Forward', 201, 'Seville', 147, 119, 35, 105, 67),
(119, 'Diaz', 'Midfield', 201, 'Seville', 113, 71, 111, 53, 297),
(120, 'Cisco', 'Forward', 205, 'Milan City', 174, 103, 62, 53, 65),
(121, 'Spataro', 'Forward', 205, 'Milan City', 94, 74, 13, 60, 5),
(122, 'Lo Coco', 'Forward', 205, 'Milan City', 42, 39, 32, 20, 78),
(123, 'NGuessan', 'Midfield', 205, 'Milan City', 23, 2, 16, 0, 49),
(124, 'Zaha', 'Forward', 205, 'Milan City', 92, 30, 42, 31, 52),
(125, 'Adeleye', 'Forward', 212, 'Woolwich Arsenal', 72, 56, 25, 11, 40),
(126, 'Pearson', 'Forward', 212, 'Woolwich Arsenal', 43, 27, 9, 15, 39),
(127, 'Adebayo', 'Forward', 212, 'Woolwich Arsenal', 52, 30, 22, 9, 16),
(128, 'Brackley', 'Midfield', 211, 'Trafford', 20, 14, 6, 4, 23),
(129, 'Ampadu', 'Midfield', 214, 'Venezia', 120, 34, 74, 5, 93),
(130, 'Naro', 'Midfield', 214, 'Venezia', 43, 37, 27, 17, 52),
(131, 'Luciano', 'Forward', 214, 'Venezia', 32, 31, 2, 24, 11),
(132, 'Wilde', 'Forward', 204, 'OL Chelsea', 101, 84, 42, 56, 62),
(133, 'van Robben', 'Midfield', 204, 'OL Chelsea', 132, 73, 167, 42, 263),
(134, 'Ericsson', 'Midfield', 204, 'OL Chelsea', 105, 21, 67, 2, 174),
(135, 'Vaux', 'Forward', 204, 'OL Chelsea', 84, 72, 6, 42, 25),
(136, 'Cheslav', 'Forward', 204, 'OL Chelsea', 32, 26, 13, 5, 53),
(137, 'McGuiness', 'Midfield', 204, 'OL Chelsea', 56, 3, 26, 0, 73),
(138, 'Texeira', 'Midfield', 204, 'OL Chelsea', 43, 12, 64, 2, 82),
(139, 'LeBeau', 'Midfield', 204, 'OL Chelsea', 73, 24, 56, 3, 195),
(140, 'Carson', 'Midfield', 210, 'AS Scows', 93, 84, 52, 73, 140),
(141, 'Lyle', 'Midfield', 210, 'AS Scows', 63, 32, 29, 14, 167),
(142, 'Serra', 'Midfield', 215, 'Santos', 45, 39, 36, 25, 93),
(143, 'Leite', 'Midfield', 215, 'Santos', 139, 23, 84, 7, 147),
(144, 'Marcelo', 'Midfield', 215, 'Santos', 85, 56, 73, 43, 83),
(145, 'Junior', 'Forward', 215, 'Santos', 74, 70, 36, 56, 62),
(146, 'Romaldinho', 'Midfield', 215, 'Santos', 158, 84, 195, 42, 284),
(147, 'Rapace', 'Forward', 216, 'Marseille', 175, 106, 42, 78, 42),
(148, 'Barbier', 'Midfield', 216, 'Marseille', 98, 5, 113, 0, 253),
(149, 'Brkovic', 'Midfield', 213, 'Gradanski Zagreb', 104, 44, 139, 17, 293),
(150, 'Perusko', 'Forward', 213, 'Gradanski Zagreb', 82, 63, 24, 53, 79),
(151, 'van den Plas', 'Forward', 206, 'Ajax', 63, 65, 46, 53, 105),
(152, 'Aart', 'Forward', 209, 'Feyenoord', 156, 135, 98, 74, 102);

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `PlayerID` int(11) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `FirstName` varchar(30) NOT NULL,
  `DOB` date NOT NULL,
  `Nationality` varchar(30) DEFAULT NULL,
  `ClubName` varchar(30) DEFAULT NULL,
  `TeamID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`PlayerID`, `LastName`, `FirstName`, `DOB`, `Nationality`, `ClubName`, `TeamID`) VALUES
(100, 'Macias', 'Juan Jose', '1999-09-02', 'Spanish', 'Seville', 201),
(101, 'Shevchonskyi', 'Mykhailo', '2002-10-01', 'Ukranian', 'Real Madrileno', 202),
(102, 'Snijders', 'Lesley', '2004-03-24', 'Dutch', 'Feyenoord', 209),
(103, 'Webb', 'Archie', '2000-07-17', 'English', 'SL Benfica', 203),
(104, 'Romarizinho', 'Oliveira Santos', '1999-09-08', 'Brazilian', 'Flamengo', 208),
(105, 'Silva da Cruz', 'Thiago', '2003-10-21', 'Brazilian', 'Ajax', 206),
(106, 'Novikov', 'Havrylo', '2000-05-01', 'Ukranian', 'Milan City', 205),
(107, 'Canez', 'Tacito', '2002-10-14', 'Spanish', 'Catalunya', 207),
(108, 'Black', 'Elliot', '2003-07-02', 'Mexican', 'OL Chelsea', 204),
(109, 'Frese', 'Bas', '2005-01-10', 'Dutch', 'Real Madrileno', 202),
(110, 'Germain', 'Raymond', '1999-12-30', 'French', 'Seville', 201),
(111, 'Luz', 'Nicodemo', '2001-06-29', 'Portuguese', 'SL Benfica', 203),
(112, 'Ramos', 'Raul', '2006-02-14', 'Spanish', 'Real Madrileno', 202),
(113, 'Botero', 'Pablo', '2004-06-30', 'Spanish', 'Real Madrileno', 202),
(114, 'Ricci', 'Quito', '2004-04-15', 'Argentine', 'OL Chelsea', 204),
(115, 'Deschamps', 'Olivier', '2000-06-07', 'French', 'Real Madrileno', 202),
(116, 'Bielsa', 'Mauro', '2005-10-12', 'Spanish', 'Real Madrileno', 202),
(117, 'Soares', 'Cleto', '2003-12-04', 'Portuguese', 'Real Madrileno', 202),
(118, 'Ferron', 'Miquel', '2005-08-19', 'Spanish', 'Seville', 201),
(119, 'Diaz', 'Artiz', '2000-01-17', 'Spanish', 'Seville', 201),
(120, 'Cisco', 'Gioele', '2000-10-01', 'Italian', 'Milan City', 205),
(121, 'Spataro', 'Senofonte', '2001-11-23', 'Italian', 'Milan City', 205),
(122, 'Lo Coco', 'Zena', '2004-09-22', 'Italian', 'Milan City', 205),
(123, 'NGuessan', 'Brou', '2005-03-12', 'Senegalese', 'Milan City', 205),
(124, 'Zaha', 'Andrew', '2003-01-27', 'Ivorian', 'Milan City', 205),
(125, 'Adeleye', 'Bukayo', '2004-05-18', 'English', 'Woolwich Arsenal', 212),
(126, 'Pearson', 'Charlie', '2004-07-31', 'English', 'Woolwich Arsenal', 212),
(127, 'Adebayo', 'Ayo', '2002-06-03', 'Nigerian', 'Woolwich Arsenal', 212),
(128, 'Brackley', 'Jordan', '2001-12-24', 'English', 'Trafford', 211),
(129, 'Ampadu', 'Esson', '2003-04-01', 'Ghanaian', 'Venezia', 214),
(130, 'Naro', 'Nicezio', '2005-08-11', 'Italian', 'Venezia', 214),
(131, 'Luciano', 'Carlito', '2000-10-03', 'Italian', 'Venezia', 214),
(132, 'Wilde', 'Luca', '2004-01-11', 'English', 'OL Chelsea', 204),
(133, 'van Robben', 'Michael', '2003-09-14', 'Dutch', 'OL Chelsea', 204),
(134, 'Ericsson', 'Kent', '2003-12-26', 'Swedish', 'OL Chelsea', 204),
(135, 'Vaux', 'Curtis', '2003-02-17', 'England', 'OL Chelsea', 204),
(136, 'Cheslav', 'Golubov', '2004-06-24', 'Ukranian', 'OL Chelsea', 204),
(137, 'McGuiness', 'George', '2003-12-14', 'Scottish', 'OL Chelsea', 204),
(138, 'Texeira', 'Joao', '2005-07-29', 'Portuguese', 'OL Chelsea', 204),
(139, 'LeBeau', 'Cupid', '2004-04-02', 'English', 'OL Chelsea', 204),
(140, 'Carson', 'Levi', '2003-01-29', 'English', 'AS Scows', 210),
(141, 'Lyle', 'Sam', '2002-06-16', 'English', 'AS Scows', 210),
(142, 'Serra', 'Arthur', '2005-03-14', 'Brazilian', 'Santos', 215),
(143, 'Leite', 'Pablo', '2002-11-07', 'Brazilian', 'Santos', 215),
(144, 'Marcelo', 'Luca', '2004-11-26', 'Brazilian', 'Santos', 215),
(145, 'Junior', 'Roque', '2002-11-23', 'Brazilian', 'Santos', 215),
(146, 'Romaldinho', 'Gilson', '2001-12-01', 'Brazilian', 'Santos', 215),
(147, 'Rapace', 'Noe', '2003-02-20', 'French', 'Marseille', 216),
(148, 'Barbier', 'Ludovic', '2004-08-30', 'French', 'Marseille', 216),
(149, 'Brkovic', 'Renato', '2002-03-21', 'Croatian', 'Gradanski Zagreb', 213),
(150, 'Perusko', 'Josip', '2001-04-01', 'Croatian', 'Gradanski Zagreb', 213),
(151, 'van den Plas', 'Thies', '2000-06-28', 'Dutch', 'Ajax', 206),
(152, 'Aart', 'Elco', '2005-03-12', 'Dutch', 'Feyenoord', 209),
(153, 'Ferdinand', 'Cicero', '2003-01-10', 'English', 'Real Madrileno', 202);

-- --------------------------------------------------------

--
-- Table structure for table `transferstatus`
--

CREATE TABLE `transferstatus` (
  `PlayerID` int(11) DEFAULT NULL,
  `AskingPriceMillions` decimal(11,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transferstatus`
--

INSERT INTO `transferstatus` (`PlayerID`, `AskingPriceMillions`) VALUES
(100, '24'),
(101, '80'),
(102, '71'),
(103, '64'),
(104, '90'),
(105, '44'),
(106, '35'),
(107, '60'),
(108, '125'),
(109, '73'),
(110, '38'),
(111, '170'),
(112, '50'),
(113, '80'),
(114, '90'),
(115, '170'),
(116, '45'),
(117, '80'),
(118, '100'),
(119, '70'),
(120, '65'),
(121, '80'),
(111, '170'),
(112, '50'),
(113, '80'),
(114, '90'),
(115, '170'),
(116, '45'),
(117, '80'),
(118, '100'),
(119, '70'),
(120, '65'),
(121, '80'),
(122, '130'),
(123, '110'),
(124, '40'),
(125, '50'),
(126, '70'),
(127, '90'),
(128, '100'),
(129, '20'),
(130, '60'),
(131, '70'),
(132, '80'),
(133, '95'),
(134, '105'),
(136, '70'),
(137, '50'),
(111, '170'),
(112, '50'),
(113, '80'),
(114, '90'),
(115, '170'),
(116, '45'),
(117, '80'),
(118, '100'),
(119, '70'),
(120, '65'),
(121, '80'),
(122, '130'),
(123, '110'),
(124, '40'),
(125, '50'),
(126, '70'),
(127, '90'),
(128, '100'),
(129, '20'),
(130, '60'),
(131, '70'),
(132, '80'),
(133, '95'),
(134, '105'),
(136, '70'),
(137, '50'),
(138, '80'),
(139, '70'),
(140, '120');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clubs`
--
ALTER TABLE `clubs`
  ADD PRIMARY KEY (`TeamID`);

--
-- Indexes for table `gamestats`
--
ALTER TABLE `gamestats`
  ADD KEY `PlayerID` (`PlayerID`),
  ADD KEY `TeamID` (`TeamID`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`PlayerID`),
  ADD KEY `TeamID` (`TeamID`);

--
-- Indexes for table `transferstatus`
--
ALTER TABLE `transferstatus`
  ADD KEY `PlayerID` (`PlayerID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gamestats`
--
ALTER TABLE `gamestats`
  ADD CONSTRAINT `gamestats_ibfk_1` FOREIGN KEY (`PlayerID`) REFERENCES `players` (`PlayerID`),
  ADD CONSTRAINT `gamestats_ibfk_2` FOREIGN KEY (`TeamID`) REFERENCES `clubs` (`TeamID`);

--
-- Constraints for table `players`
--
ALTER TABLE `players`
  ADD CONSTRAINT `players_ibfk_1` FOREIGN KEY (`TeamID`) REFERENCES `clubs` (`TeamID`);

--
-- Constraints for table `transferstatus`
--
ALTER TABLE `transferstatus`
  ADD CONSTRAINT `transferstatus_ibfk_1` FOREIGN KEY (`PlayerID`) REFERENCES `players` (`PlayerID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
